﻿using System;
using System.Diagnostics;
using System.Threading;

class Program
{
    static void Main()
    {
        int worldWidth = 80;
        int worldHeight = 20;

        Console.SetWindowSize(Math.Max(worldWidth, 20), Math.Max(worldHeight, 20));
        Console.SetBufferSize(Math.Max(worldWidth, 20), Math.Max(worldHeight, 20));
        Console.CursorVisible = false;

        float playerX = 20;
        float playerY = 10;
        float velocityY = 0;

        float gravity = 30f;
        float jumpForce = -20f;
        float moveSpeed = 25f;
        float scrollSpeed = 15f;

        float jumpHeight = (jumpForce * jumpForce) / (2 * gravity);
        float airTime = (2 * -jumpForce) / gravity;
        float jumpDistance = scrollSpeed * airTime;

        bool isGrounded = false;
        bool onPlatform = false;
        bool onFloor = false;

        float scoreTimer = 0f;
        int score = 0;

        Random rand = new Random();
        int platformCount = 8;
        int minPlatformWidth = 5;
        int maxPlatformWidth = 12;

        float[,] platforms = new float[platformCount, 3];

        int floorY = worldHeight - 2;
        int topMargin = 3;
        int previousY = floorY;

        float currentX = 0;
        for (int i = 0; i < platformCount; i++)
        {
            int maxY = Math.Max(topMargin, previousY - (int)jumpHeight);
            int upper = Math.Max(maxY, previousY - 1);

            platforms[i, 2] = rand.Next(maxY, upper + 1);
            platforms[i, 1] = rand.Next(minPlatformWidth, maxPlatformWidth);
            platforms[i, 0] = currentX;

            currentX += jumpDistance * 0.8f;
            previousY = (int)platforms[i, 2];
        }

        Stopwatch sw = Stopwatch.StartNew();

        while (true)
        {
            double dt = sw.Elapsed.TotalSeconds;
            sw.Restart();

            // INPUT
            float moveInput = 0;
            if (Console.KeyAvailable)
            {
                var key = Console.ReadKey(true).Key;

                if (key == ConsoleKey.A || key == ConsoleKey.LeftArrow) moveInput = -1;
                if (key == ConsoleKey.D || key == ConsoleKey.RightArrow) moveInput = 1;

                if (key == ConsoleKey.Spacebar && isGrounded)
                {
                    velocityY = jumpForce;
                    isGrounded = false;
                }

                if (key == ConsoleKey.Escape) return;
            }

            // PLAYER HORIZONTAL
            playerX += moveInput * moveSpeed * (float)dt;
            playerX = Math.Clamp(playerX, 0, worldWidth - 1);

            // SCROLL WORLD
            for (int i = 0; i < platformCount; i++)
            {
                platforms[i, 0] -= scrollSpeed * (float)dt;
            }

            // RECYCLE PLATFORMS
            for (int i = 0; i < platformCount; i++)
            {
                if (platforms[i, 0] + platforms[i, 1] < 0)
                {
                    float rightMost = 0;
                    for (int j = 0; j < platformCount; j++)
                    {
                        if (platforms[j, 0] > rightMost)
                            rightMost = platforms[j, 0];
                    }

                    float spacing = jumpDistance * 0.8f;

                    platforms[i, 0] = rightMost + spacing;
                    platforms[i, 1] = rand.Next(minPlatformWidth, maxPlatformWidth);
                    platforms[i, 2] = rand.Next(topMargin, floorY);
                }
            }

            // PHYSICS
            velocityY += gravity * (float)dt;
            playerY += velocityY * (float)dt;

            isGrounded = false;
            onPlatform = false;
            onFloor = false;

            // PLATFORM COLLISION FIRST
            for (int i = 0; i < platformCount; i++)
            {
                int platX = (int)platforms[i, 0];
                int platW = (int)platforms[i, 1];
                int platY = (int)platforms[i, 2];

                if (velocityY >= 0 &&
                    playerY >= platY - 1 &&
                    playerY <= platY &&
                    playerX >= platX &&
                    playerX <= platX + platW)
                {
                    playerY = platY - 1;
                    velocityY = 0;
                    isGrounded = true;
                    onPlatform = true;
                    break;
                }
            }

            // FLOOR COLLISION ONLY IF NOT ON PLATFORM
            if (!onPlatform && playerY >= floorY)
            {
                playerY = floorY;
                velocityY = 0;
                isGrounded = true;
                onFloor = true;
            }

            playerY = Math.Clamp(playerY, 0, floorY);

            // ==========================
            // SIMPLIFIED SCORE SYSTEM
            // ==========================
            if (onFloor)
            {
                score = 0;
                scoreTimer = 0f;
            }
            else
            {
                scoreTimer += (float)dt;
                while (scoreTimer >= 1f)
                {
                    score++;
                    scoreTimer -= 1f;
                }
            }

            // ==========================
            // RENDER USING BACK BUFFER
            // ==========================
            char[,] buffer = new char[worldHeight, worldWidth];

            // Fill with spaces
            for (int y = 0; y < worldHeight; y++)
                for (int x = 0; x < worldWidth; x++)
                    buffer[y, x] = ' ';

            // Draw score
            string scoreText = $"Score: {score}";
            for (int i = 0; i < scoreText.Length && i < worldWidth; i++)
                buffer[0, i] = scoreText[i];

            // Draw floor
            for (int x = 0; x < worldWidth; x++)
                buffer[worldHeight - 1, x] = '#';

            // Draw platforms
            for (int i = 0; i < platformCount; i++)
            {
                int drawX = (int)platforms[i, 0];
                int drawY = (int)platforms[i, 2];
                int width = (int)platforms[i, 1];

                for (int x = 0; x < width; x++)
                {
                    int px = drawX + x;
                    if (px >= 0 && px < worldWidth && drawY >= 0 && drawY < worldHeight)
                        buffer[drawY, px] = '-';
                }
            }

            // Draw player
            int pX = (int)playerX;
            int pY = (int)playerY;
            if (pX >= 0 && pX < worldWidth && pY >= 0 && pY < worldHeight)
                buffer[pY, pX] = '■';

            // Render buffer
            Console.SetCursorPosition(0, 0);
            for (int y = 0; y < worldHeight; y++)
            {
                for (int x = 0; x < worldWidth; x++)
                    Console.Write(buffer[y, x]);

                if (y < worldHeight - 1)
                    Console.WriteLine();
            }

            Thread.Sleep(16);
        }
    }
}